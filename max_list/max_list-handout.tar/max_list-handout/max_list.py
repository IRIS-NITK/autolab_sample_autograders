# Find the max element of a list containing of integers
"""
@param list of integers
@return integer
"""
def max_list(list):
    # Complete the code
    pass
if __name__ == "__main__":
   import sys
   print(max_list(map(int, sys.argv[1].split(" "))))
